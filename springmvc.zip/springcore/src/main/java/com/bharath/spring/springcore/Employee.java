package com.bharath.spring.springcore;

public class Employee {

	private int id;
	private String name;

	//// getter and setter for id
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	//// getter and setter for name
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
