package com.bharath.spring.springcoreadvanced.injecting.interfaces;

public interface OrderDAO {

	void createOrder();
}
